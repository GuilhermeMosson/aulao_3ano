    <?php
        $nota1 =readline('nota 1: ');
        $nota2 =readline('nota 2: ');
        $nota3 =readline('nota 3: ');
        $nota4 =readline('nota 4: ');
        $nota5 =readline('nota 5: ');
    
        $media = ($nota1 + $nota2 + $nota3 + $nota4 + $nota5) / 5;
        
        switch($media){
            case 'media >= 90':
                echo "Nota A";
                break;
            case 'media < 90 && media >= 80 ':
                echo "Nota B";
                break;
            case 'media > 80 && media >= 70':
                echo "Nota C";
                break;
                case 'media > 80 && media >= 70':
                    echo "Nota C";
                    break;
        }
    ?>